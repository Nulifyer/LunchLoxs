---
title: "Pad Thai"
tags: ["thai", "noodles", "quick"]
servings: 2
prepMinutes: 20
cookMinutes: 10
createdAt: 2026-03-25T01:12:55.251Z
updatedAt: 2026-03-25T01:12:55.251Z
---

## Ingredients

| Qty | Unit   | Ingredient                         |
| --- | ------ | ---------------------------------- |
| 200 | g      | flat rice noodles                  |
| 200 | g      | shrimp or chicken, sliced          |
| 2   |        | eggs                               |
| 3   | tbsp   | fish sauce                         |
| 2   | tbsp   | tamarind paste                     |
| 1   | tbsp   | palm sugar or brown sugar          |
| 2   | cloves | garlic, minced                     |
| 1   | cup    | bean sprouts                       |
| 3   |        | green onions, cut in 2-inch pieces |
| 1/4 | cup    | roasted peanuts, crushed           |
| 1   |        | lime, cut into wedges              |

## Instructions

Soak rice noodles in warm water for 30 minutes until pliable. Drain.

Mix fish sauce, tamarind paste, and sugar in a small bowl.

Heat oil in a wok over high heat. Cook protein until done, set aside.

Add garlic, cook 15 seconds. Push aside, crack eggs into the wok and scramble.

Add noodles and sauce mixture. Toss with tongs for 2 minutes.

Return protein. Add bean sprouts and green onions. Toss 30 seconds.

Serve with crushed peanuts and lime wedges.
