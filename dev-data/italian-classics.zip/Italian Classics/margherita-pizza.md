---
title: "Margherita Pizza"
tags: ["italian", "pizza", "baking"]
servings: 2
prepMinutes: 120
cookMinutes: 12
createdAt: 2026-03-25T01:12:55.242Z
updatedAt: 2026-03-25T01:12:55.242Z
---

## Ingredients

| Qty | Unit  | Ingredient                    |
| --- | ----- | ----------------------------- |
| 500 | g     | tipo 00 flour                 |
| 325 | ml    | warm water                    |
| 10  | g     | salt                          |
| 3   | g     | active dry yeast              |
| 400 | g     | San Marzano tomatoes, crushed |
| 250 | g     | fresh mozzarella              |
| 1   | bunch | fresh basil                   |
| 2   | tbsp  | extra virgin olive oil        |

## Instructions

Dissolve yeast in warm water, let sit 5 minutes. Mix flour and salt, add water gradually. Knead 10 minutes until smooth and elastic. Cover and rise 1-2 hours.

Preheat oven to the highest setting (250C/500F) with a baking stone or inverted baking sheet.

Divide dough in two. Stretch each ball into a thin round by hand -- don't use a rolling pin.

Spread crushed tomatoes lightly. Tear mozzarella over top. Drizzle with olive oil.

Bake 10-12 minutes until the crust is charred in spots and the cheese is bubbling.

Add fresh basil leaves after removing from oven.
