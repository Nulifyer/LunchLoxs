---
title: "Classic French Crepes"
tags: ["french", "breakfast", "dessert"]
servings: 8
prepMinutes: 35
cookMinutes: 20
createdAt: 2026-03-25T01:12:55.255Z
updatedAt: 2026-03-25T01:12:55.255Z
---

## Ingredients

| Qty | Unit | Ingredient        |
| --- | ---- | ----------------- |
| 1   | cup  | all-purpose flour |
| 2   |      | eggs              |
| 1/2 | cup  | milk              |
| 1/2 | cup  | water             |
| 1/4 | tsp  | salt              |
| 2   | tbsp | melted butter     |

## Instructions

Blend flour, eggs, milk, water, salt, and butter until smooth. Refrigerate batter 30 minutes.

Heat a lightly buttered crepe pan or non-stick skillet over medium-high heat.

Pour approximately 1/4 cup batter, tilting the pan to spread evenly into a thin circle.

Cook about 2 minutes until the bottom is light brown. Flip and cook 1 more minute.

Fill with Nutella and bananas, lemon and sugar, ham and cheese, or your choice.
