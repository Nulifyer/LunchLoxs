---
title: "Banana Bread"
tags: ["baking", "bread", "breakfast"]
servings: 10
prepMinutes: 15
cookMinutes: 60
createdAt: 2026-03-25T01:12:55.254Z
updatedAt: 2026-03-25T01:12:55.254Z
---

## Ingredients

| Qty   | Unit | Ingredient                  |
| ----- | ---- | --------------------------- |
| 3     |      | very ripe bananas, mashed   |
| 1/3   | cup  | melted butter               |
| 3/4   | cup  | sugar                       |
| 1     |      | egg, beaten                 |
| 1     | tsp  | vanilla extract             |
| 1     | tsp  | baking soda                 |
| 1/4   | tsp  | salt                        |
| 1 1/2 | cups | all-purpose flour           |
| 1/2   | cup  | walnuts, chopped (optional) |

## Instructions

Preheat oven to 350F (175C). Grease a 9x5 inch loaf pan.

Mash bananas in a large bowl. Stir in melted butter.

Mix in sugar, egg, and vanilla. Add baking soda and salt. Fold in flour until just combined. Add walnuts if using.

Pour into prepared pan.

Bake 55-65 minutes until a toothpick comes out clean.

Cool in pan 10 minutes, then turn out onto a wire rack.
