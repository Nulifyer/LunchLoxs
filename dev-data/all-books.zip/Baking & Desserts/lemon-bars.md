---
title: "Lemon Bars"
tags: ["baking", "dessert", "citrus"]
servings: 16
prepMinutes: 15
cookMinutes: 40
createdAt: 2026-03-25T01:12:55.255Z
updatedAt: 2026-03-25T01:12:55.255Z
---

## Ingredients

| Qty   | Unit | Ingredient                            |
| ----- | ---- | ------------------------------------- |
| 1     | cup  | butter, softened                      |
| 1/2   | cup  | powdered sugar, plus more for dusting |
| 2     | cups | all-purpose flour                     |
| 4     |      | large eggs                            |
| 1 1/2 | cups | granulated sugar                      |
| 1/3   | cup  | fresh lemon juice                     |
| 2     | tbsp | lemon zest                            |
| 1/4   | cup  | all-purpose flour (for filling)       |

## Instructions

Preheat oven to 350F (175C). Line a 9x13 pan with parchment.

For the crust: mix butter, powdered sugar, and 2 cups flour until crumbly. Press into pan. Bake 15-20 minutes until lightly golden.

For the filling: whisk eggs, sugar, lemon juice, zest, and 1/4 cup flour.

Pour filling over hot crust.

Bake 20-25 minutes until filling is set and edges are lightly browned.

Cool completely. Dust with powdered sugar. Cut into bars.
