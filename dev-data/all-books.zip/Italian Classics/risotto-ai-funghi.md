---
title: "Risotto ai Funghi"
tags: ["italian", "rice", "comfort food"]
servings: 4
prepMinutes: 15
cookMinutes: 30
createdAt: 2026-03-25T01:12:55.254Z
updatedAt: 2026-03-25T01:12:55.254Z
---

## Ingredients

| Qty | Unit   | Ingredient                      |
| --- | ------ | ------------------------------- |
| 320 | g      | arborio or carnaroli rice       |
| 300 | g      | mixed mushrooms, sliced         |
| 1   | L      | warm vegetable or chicken stock |
| 1   |        | small onion, finely diced       |
| 2   | cloves | garlic, minced                  |
| 120 | ml     | dry white wine                  |
| 50  | g      | butter                          |
| 60  | g      | parmesan, grated                |
| 2   | tbsp   | olive oil                       |
|     |        | fresh thyme and parsley         |

## Instructions

Saute mushrooms in olive oil over high heat until golden. Season and set aside.

In the same pan, melt half the butter. Cook onion until translucent, about 5 minutes. Add garlic for 30 seconds.

Add rice and toast for 2 minutes, stirring constantly. Deglaze with wine and stir until absorbed.

Add warm stock one ladle at a time, stirring frequently. Wait until each addition is mostly absorbed before adding the next. This takes about 18-20 minutes.

When rice is creamy but still has a slight bite, remove from heat. Stir in remaining butter, parmesan, and the reserved mushrooms.

Cover and rest 2 minutes. Serve garnished with herbs.
