---
title: "Spaghetti Carbonara"
tags: ["italian", "pasta", "quick"]
servings: 4
prepMinutes: 10
cookMinutes: 15
createdAt: 2026-03-25T01:12:55.254Z
updatedAt: 2026-03-25T01:12:55.254Z
---

## Ingredients

| Qty | Unit | Ingredient                     |
| --- | ---- | ------------------------------ |
| 400 | g    | spaghetti                      |
| 200 | g    | guanciale or pancetta          |
| 4   |      | large egg yolks                |
| 2   |      | whole eggs                     |
| 100 | g    | pecorino romano, finely grated |
|     |      | freshly cracked black pepper   |

## Instructions

Bring a large pot of salted water to a rolling boil. Cook spaghetti until al dente.

Meanwhile, cut guanciale into small strips. Cook in a cold pan over medium heat until the fat renders and the meat is crispy, about 8 minutes.

In a bowl, whisk egg yolks, whole eggs, and most of the pecorino. Add generous black pepper.

When pasta is ready, reserve 1 cup pasta water. Drain and add to the guanciale pan (heat OFF). Toss to coat.

Pour the egg mixture over the pasta, tossing vigorously. Add splashes of pasta water to create a creamy sauce. The residual heat cooks the eggs without scrambling.

Serve immediately with remaining pecorino and more pepper.

## Notes

Never add cream. The creaminess comes from the egg and cheese emulsion. Use the best pecorino you can find.
