---
title: "Tiramisu"
tags: ["italian", "dessert", "no-bake"]
servings: 8
prepMinutes: 30
cookMinutes: 0
createdAt: 2026-03-25T01:12:55.254Z
updatedAt: 2026-03-25T01:12:55.254Z
---

## Ingredients

| Qty | Unit | Ingredient                      |
| --- | ---- | ------------------------------- |
| 6   |      | egg yolks                       |
| 150 | g    | sugar                           |
| 500 | g    | mascarpone cheese               |
| 300 | ml   | strong espresso, cooled         |
| 3   | tbsp | coffee liqueur (optional)       |
| 300 | g    | savoiardi (ladyfinger biscuits) |
| 2   | tbsp | unsweetened cocoa powder        |

## Instructions

Whisk egg yolks and sugar until thick and pale, about 5 minutes with an electric mixer.

Fold in mascarpone gently until smooth. Do not overmix.

Combine cooled espresso and liqueur in a shallow dish.

Quickly dip each ladyfinger in the coffee (don't soak -- just a brief dip on each side).

Layer dipped ladyfingers in a 9x13 dish. Spread half the mascarpone cream. Repeat layers.

Cover and refrigerate at least 4 hours, ideally overnight.

Dust generously with cocoa powder before serving.

## Notes

The longer it rests, the better the flavors meld. Can be made 2 days ahead.
