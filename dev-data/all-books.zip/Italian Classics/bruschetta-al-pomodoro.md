---
title: "Bruschetta al Pomodoro"
tags: ["italian", "appetizer", "quick"]
servings: 6
prepMinutes: 15
cookMinutes: 5
createdAt: 2026-03-25T01:12:55.254Z
updatedAt: 2026-03-25T01:12:55.254Z
---

## Ingredients

| Qty | Unit    | Ingredient                   |
| --- | ------- | ---------------------------- |
| 6   |         | ripe roma tomatoes, diced    |
| 1   | clove   | garlic, minced               |
| 1   | handful | fresh basil, torn            |
| 3   | tbsp    | extra virgin olive oil       |
| 1   | tbsp    | balsamic vinegar             |
| 1   |         | baguette or ciabatta, sliced |
|     |         | salt and pepper to taste     |

## Instructions

Combine diced tomatoes, garlic, basil, olive oil, and balsamic. Season with salt and pepper. Let sit 10 minutes.

Toast bread slices under the broiler or on a grill until golden, about 2 minutes per side.

Rub each toast with a cut garlic clove (optional).

Spoon tomato mixture onto toasts. Drizzle with extra olive oil. Serve immediately.
