---
title: "Vegetable Stir-Fry with Tofu"
tags: ["chinese", "vegetarian", "quick", "healthy"]
servings: 3
prepMinutes: 15
cookMinutes: 10
createdAt: 2026-03-25T01:12:55.254Z
updatedAt: 2026-03-25T01:12:55.254Z
---

## Ingredients

| Qty | Unit   | Ingredient                       |
| --- | ------ | -------------------------------- |
| 400 | g      | firm tofu, cubed and pressed     |
| 1   |        | red bell pepper, sliced          |
| 1   |        | broccoli crown, cut into florets |
| 2   |        | baby bok choy, halved            |
| 3   | tbsp   | soy sauce                        |
| 1   | tbsp   | sesame oil                       |
| 1   | tbsp   | rice vinegar                     |
| 1   | tsp    | cornstarch                       |
| 1   | tsp    | chili flakes                     |
| 2   | cloves | garlic, sliced                   |
| 1   | inch   | ginger, grated                   |

## Instructions

Press tofu for 15 minutes. Cut into cubes.

Mix soy sauce, sesame oil, rice vinegar, and cornstarch for the sauce.

Heat oil in a wok over high heat. Fry tofu until golden on all sides, about 5 minutes. Remove.

Add garlic and ginger, cook 30 seconds. Add broccoli and bell pepper, stir-fry 3 minutes.

Add bok choy and sauce. Toss 1 minute.

Return tofu, add chili flakes. Toss to coat.

Serve over steamed rice or noodles.
