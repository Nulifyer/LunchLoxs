---
title: "Japanese Chicken Katsu Curry"
tags: ["japanese", "curry", "comfort food"]
servings: 4
prepMinutes: 20
cookMinutes: 40
createdAt: 2026-03-25T01:12:55.254Z
updatedAt: 2026-03-25T01:12:55.254Z
---

## Ingredients

| Qty | Unit   | Ingredient                                    |
| --- | ------ | --------------------------------------------- |
| 4   |        | boneless chicken thighs                       |
| 1   | cup    | panko breadcrumbs                             |
| 1/2 | cup    | all-purpose flour                             |
| 2   |        | eggs, beaten                                  |
| 1   |        | onion, diced                                  |
| 2   |        | carrots, cubed                                |
| 2   |        | potatoes, cubed                               |
| 2   | blocks | Japanese curry roux (Golden Curry or similar) |
| 600 | ml     | water                                         |
|     |        | steamed rice for serving                      |
|     |        | oil for frying                                |

## Instructions

For the curry: saute onion until soft. Add carrots and potatoes, cook 3 minutes. Add water, bring to a boil. Simmer 15 minutes until vegetables are tender.

Turn off heat, add curry roux blocks. Stir until dissolved. Simmer on low 5 more minutes until thick.

For the katsu: pound chicken to even thickness. Season with salt and pepper. Dredge in flour, dip in egg, coat in panko.

Shallow fry in 1cm of oil at 170C/340F for 4-5 minutes per side until golden and cooked through. Drain on a wire rack.

Slice katsu. Serve over rice with curry sauce ladled alongside.
