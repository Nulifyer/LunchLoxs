---
title: "Thai Green Curry"
tags: ["thai", "curry", "spicy"]
servings: 4
prepMinutes: 15
cookMinutes: 20
createdAt: 2026-03-25T01:12:55.254Z
updatedAt: 2026-03-25T01:12:55.254Z
---

## Ingredients

| Qty | Unit    | Ingredient                               |
| --- | ------- | ---------------------------------------- |
| 400 | ml      | coconut milk                             |
| 3   | tbsp    | green curry paste                        |
| 500 | g       | chicken thigh, sliced                    |
| 1   |         | Thai eggplant or regular eggplant, cubed |
| 1   | handful | Thai basil leaves                        |
| 2   | tbsp    | fish sauce                               |
| 1   | tbsp    | palm sugar                               |
| 4   |         | kaffir lime leaves                       |
| 1   |         | red chili, sliced                        |

## Instructions

Heat a splash of coconut cream (the thick part from the top of the can) in a wok. Fry curry paste for 2 minutes until fragrant.

Add chicken and cook until sealed on all sides.

Pour in remaining coconut milk, fish sauce, and palm sugar. Add kaffir lime leaves.

Bring to a gentle simmer. Add eggplant. Cook 10-15 minutes until chicken is cooked through and eggplant is tender.

Stir in Thai basil. Garnish with sliced chili.

Serve with jasmine rice.
