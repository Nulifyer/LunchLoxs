---
title: "Miso Ramen"
tags: ["japanese", "soup", "noodles", "comfort food"]
servings: 2
prepMinutes: 15
cookMinutes: 20
createdAt: 2026-03-25T01:12:55.254Z
updatedAt: 2026-03-25T01:12:55.254Z
---

## Ingredients

| Qty | Unit     | Ingredient                                  |
| --- | -------- | ------------------------------------------- |
| 2   | portions | fresh ramen noodles                         |
| 3   | tbsp     | white miso paste                            |
| 1   | tbsp     | sesame paste or tahini                      |
| 800 | ml       | chicken or pork stock                       |
| 1   | tbsp     | soy sauce                                   |
| 2   |          | soft-boiled eggs, halved                    |
| 100 | g        | chashu pork or sliced pork belly            |
| 2   |          | green onions, sliced                        |
|     |          | nori sheets, corn, bean sprouts for topping |

## Instructions

Bring stock to a simmer. Whisk in miso paste and sesame paste until smooth. Add soy sauce. Keep warm but do not boil (boiling destroys miso flavor).

Cook ramen noodles according to package (usually 2-3 minutes). Drain.

If using pork belly, sear slices in a hot pan until caramelized.

Divide noodles between bowls. Ladle hot broth over noodles.

Top with halved soft-boiled egg, pork, green onions, nori, corn, and bean sprouts.

## Notes

For the soft-boiled eggs: boil 6.5 minutes, then ice bath. Marinate in soy sauce and mirin overnight for ajitama.
