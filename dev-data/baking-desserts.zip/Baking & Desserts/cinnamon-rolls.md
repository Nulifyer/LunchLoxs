---
title: "Cinnamon Rolls"
tags: ["baking", "breakfast", "comfort food"]
servings: 12
prepMinutes: 120
cookMinutes: 25
createdAt: 2026-03-25T01:12:55.252Z
updatedAt: 2026-03-25T01:12:55.252Z
---

## Ingredients

| Qty   | Unit | Ingredient                |
| ----- | ---- | ------------------------- |
| 4     | cups | all-purpose flour         |
| 1/3   | cup  | sugar                     |
| 1     | tsp  | salt                      |
| 2 1/4 | tsp  | instant yeast             |
| 1     | cup  | warm milk                 |
| 1/3   | cup  | butter, melted            |
| 2     |      | eggs                      |
| 1     | cup  | brown sugar (filling)     |
| 2 1/2 | tbsp | cinnamon (filling)        |
| 1/3   | cup  | softened butter (filling) |
| 4     | oz   | cream cheese (glaze)      |
| 1     | cup  | powdered sugar (glaze)    |
| 1     | tsp  | vanilla (glaze)           |

## Instructions

Mix flour, sugar, salt, and yeast. Add warm milk, melted butter, and eggs. Knead 8 minutes until smooth. Rise 1 hour.

Roll dough into a large rectangle, about 16x12 inches. Spread softened butter over surface. Sprinkle brown sugar and cinnamon evenly.

Roll up tightly from the long side. Cut into 12 equal pieces.

Place in a greased 9x13 pan. Cover and rise 30 minutes.

Bake at 350F (175C) for 22-25 minutes until golden.

For glaze: beat cream cheese, powdered sugar, and vanilla until smooth. Spread over warm rolls.

## Notes

For overnight rolls: after cutting and placing in pan, cover and refrigerate overnight. Let come to room temperature 30 minutes before baking.
