---
title: "Chocolate Chip Cookies"
tags: ["baking", "cookies", "dessert"]
servings: 24
prepMinutes: 15
cookMinutes: 12
createdAt: 2026-03-25T01:12:55.252Z
updatedAt: 2026-03-25T01:12:55.252Z
---

## Ingredients

| Qty   | Unit | Ingredient         |
| ----- | ---- | ------------------ |
| 2 1/4 | cups | all-purpose flour  |
| 1     | tsp  | baking soda        |
| 1     | tsp  | salt               |
| 1     | cup  | butter, softened   |
| 3/4   | cup  | granulated sugar   |
| 3/4   | cup  | packed brown sugar |
| 2     |      | large eggs         |
| 2     | tsp  | vanilla extract    |
| 2     | cups | chocolate chips    |

## Instructions

Preheat oven to 375F (190C).

Whisk flour, baking soda, and salt in a bowl.

Beat butter and both sugars until light and fluffy, about 3 minutes. Add eggs one at a time, then vanilla.

Gradually mix in flour mixture on low speed. Fold in chocolate chips.

Drop rounded tablespoons onto ungreased baking sheets, spacing 2 inches apart.

Bake 9-11 minutes until edges are golden but centers look slightly underdone.

Cool on baking sheet 5 minutes, then transfer to a wire rack.

## Notes

For extra flavor, refrigerate the dough overnight. Brown the butter for a nutty depth.
